sap.ui.define(function () {
	"use strict";

	var Formatter = {

		availableState: function (ValueState) {
		//	var sStateValueToLower = sStateValue.Status();

			switch (ValueState) {
				case "New PO":
					return 8;
				case "Old PO":
					return 3;
				case "Goods Reciept Completed":
					return 6;
				case "Invoice Reciept Completed":
					return 1;
				case "ASN Created":
					return 7;
					default:
					return 9;
				
				
			}
			
			 
		}
	};

	return Formatter;

}, /* bExport= */ true);
