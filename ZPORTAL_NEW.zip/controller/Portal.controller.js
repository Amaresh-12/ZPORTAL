sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV",
	"../Formatter"
], function (Controller, JSONModel, Filter, FilterOperator, MessageToast, MessageBox, Export, ExportTypeCSV, Formatter) {
	"use strict";

	return Controller.extend("com.app.portal.PORTAL.controller.Portal", {
		formatter: Formatter,

		onInit: function () {
			var URL = "/sap/opu/odata/SAP/ZUPLOAD_FILE_NEW_SRV/";
			var oData = new sap.ui.model.odata.ODataModel(URL, false);
			var errorlogs = [];
			var oDataModel = new sap.ui.model.json.JSONModel();
			var entity = "/ERROR_RECORDSSet";

			oData.read(entity, null, null, false,
				function (Data) {
					errorlogs = Data;

				});
			var length2 = {
				length: errorlogs.results.length
			};
			var lengthmodel2 = new sap.ui.model.json.JSONModel(length2);
			oDataModel.setData(errorlogs);
			this.getView().byId("Errorlog").setModel(oDataModel);
			this.getView().setModel(oDataModel, "Errorlog");
			//---------po table--------------

			var oData1 = new sap.ui.model.odata.ODataModel(URL, false);
			var po = [];
			var oDataModel1 = new sap.ui.model.json.JSONModel();
			var entity1 = "/PO_Display1Set";

			oData1.read(entity1, null, null, false,
				function (Data1) {
					po = Data1;

				});

			//here for count on icon tab filter
			var length = {
				length: po.results.length
			};
			var lengthmodel1 = new sap.ui.model.json.JSONModel(length);

			oDataModel1.setData(po);

			this.getView().byId("Table1").setModel(oDataModel1);
			this.getView().setModel(oDataModel1, "PODisplay");
			this.getView().setModel(lengthmodel1, "lengthModel1");
			//---------stock table-----------

			var oData2 = new sap.ui.model.odata.ODataModel(URL, false);
			var stock = [];
			var oDataModel2 = new sap.ui.model.json.JSONModel();
			var entity2 = "/zinventorySet";

			oData2.read(entity2, null, null, false,
				function (Data2) {
					stock = Data2;

				});

			//for icon tab bar count
			var length1 = {
				length: stock.results.length
			};
			var lengthmodel = new sap.ui.model.json.JSONModel(length1);
			///////end here                                                                
			oDataModel2.setData(stock);
			this.getView().byId("stocktable").setModel(oDataModel2);
			this.getView().setModel(oDataModel2, "stocktable");

		},
		//Date From and To Filter *Start*
		// handleChange: function (oEvent) {
		
			//var selected = oEvent;
			// var aFilters = [];
			// var outerFilters = [];
			// var dDateStart = new Date(oEvent.getParameter("value"));
			// var oTable = this.byId("Table1");
			// var HdateFormat = sap.ui.core.format.DateFormat.getDateInstance({
			// 	pattern: "dd.MM.yyyy"
			// });
			// dDateStart = HdateFormat.format(dDateStart);
			// var id = oEvent.getSource().getId();
			// var count = id.search("from");
			// id = id.slice(count, id.length);
			// if (id !== "from") {
			// 	dDateStart = this._DateStart;
			// 	var dDateEnd = new Date(oEvent.getParameter("value"));
			// 	dDateEnd = HdateFormat.format(dDateEnd);
			// 	aFilters.push(new Filter("Aedat", sap.ui.model.FilterOperator.Contains, dDateEnd));

			// } else {
			// 	this._DateStart = dDateStart;
			// }
			// //var isValidDate = oEvent.getParameter("valid");

			// if (dDateStart === "") {
			// 	//When clear was pressed on search field
			// 	oTable.getBinding("rows").filter(null);
			// } else {
			// 	aFilters.push(new Filter("Aedat", sap.ui.model.FilterOperator.Contains, dDateStart));

			// 	outerFilters.push(new Filter(aFilters));
			// 	//aFilters = [];
			// 	/*aFilters.push(new Filter({
			// 		path: "Aedat",
			// 		operator: FilterOperator.Contains,
			// 		value1: dDateStart,
			// 		value2: dDateEnd
			// 	}));*/
			// }

			// oTable.getBinding("rows").filter(new Filter({
			// 	filters: outerFilters,
			// 	and: true //Default is OR between filters
			// }));
		
	// var oView = this.getView();
	// var oTable = oView.byId("Table1");
	// var sValue = oEvent.getParameter("value");
	// var oBinding = oTable.getBinding("rows");
	// var oFilter = new sap.ui.model.Filter({
	// 										filters:[new sap.ui.model.Filter("Aedat", sap.ui.model.FilterOperator.Contains, sValue)]
	// 			});
				
	// 		oBinding.filter([oFilter]);
	// 	},
		// handleDRSChange: function(oEvents){
		// 	var sEvent =oEvents;
		// },
		//Date From and To Filter *End*
		onBackPress1: function (oEvent) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			//	var oModel = sap.ui.getCore().getModel("Globalmodel");
			oRouter.navTo("TargetView1");
		},

		// table refresh for Purchase Orders
		onrefresh: function () {
			var oBusyDialog = new sap.m.BusyDialog();
			oBusyDialog.open();

			var that = this;
			// debugger;
			var serviceUrl = "/sap/opu/odata/SAP/ZUPLOAD_FILE_NEW_SRV";
			var sPath = "/PO_Display1Set";
			var oModel1 = new sap.ui.model.odata.v2.ODataModel(serviceUrl, true);
			oModel1.read(sPath, {
				success: function (oData, OResponse) {
					// debugger;
					var oJSON = new JSONModel(oData);
					var otable = that.getView().byId("Table1");
					otable.setModel(oJSON);
					otable.getBinding("rows").refresh();
					that.getView().setModel(oJSON, "PODisplay");
				}
			});
			// table refresh for Error Records
			var sPath2 = "/ERROR_RECORDSSet";
			var oModel2 = new sap.ui.model.odata.v2.ODataModel(serviceUrl, true);
			oModel2.read(sPath2, {
				success: function (oData, OResponse) {
					var oJSON1 = new JSONModel(oData);
					var oerror = that.getView().byId("Errorlog");
					oerror.setModel(oJSON1);
					oerror.getBinding("rows").refresh();
					that.getView().setModel(oJSON1, "Errorlog");
				}
			});

			// table refresh for Stock
			var sPath3 = "/zinventorySet";
			var oModel3 = new sap.ui.model.odata.v2.ODataModel(serviceUrl, true);
			oModel3.read(sPath3, {
				success: function (oData, OResponse) {
					var oJSON2 = new JSONModel(oData);
					var oStock = that.getView().byId("stocktable");
					oStock.setModel(oJSON2);
					oStock.getBinding("rows").refresh();
					that.getView().setModel(oJSON2, "stocktable");
				}
			});
			Formatter.getPOTableCount();
			jQuery.sap.delayedCall(3000, this, function () {
				oBusyDialog.close();
			});
		},

		onUpload: function () {
			var sURL = "/sap/opu/odata/SAP/ZUPLOAD_FILE_NEW_SRV/";
			var sect = new sap.ui.model.odata.ODataModel(sURL, true);
			this.csrfToken = sect.getSecurityToken();
			var Fileuploader = this.getView().byId("fileUploader");
			if (!Fileuploader.getValue()) {
				sap.m.MessageBox.alert("Please Select a file to Upload");
				return;
			}
			Fileuploader.setUseMultipart(false);
			Fileuploader.setName("uploadAttachment");
			Fileuploader.setSendXHR(true);
			Fileuploader.removeAllHeaderParameters();
			Fileuploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "x-csrf-token",
				value: this.csrfToken
			}));
			var fname = Fileuploader.getValue();
			Fileuploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "slug",
				value: fname
			}));
			Fileuploader.upload();
			// document.location.reload(true);
			// var that = this;
			// that.onbinding();
		},
		handleUploadComplete: function (oEvent) {
			var oUploadCollection = oEvent.getSource();
			var fileName = oEvent.getParameter("fileName");
			// var msg = "File " + oEvent.getParameter("fileName") + " is Successfully Uploaded";
			// sap.m.MessageBox.show(msg, sap.m.MessageBox.Icon.SUCCESS, "Success");
			var URL = "/sap/opu/odata/SAP/ZUPLOAD_FILE_NEW_SRV/";
			var oData3 = new sap.ui.model.odata.ODataModel(URL, false);
			var MSG;
			var entity3 = "/Return_apSet";

			oData3.read(entity3, null, null, false, function (Data2) {
				MSG = Data2.results;
			});
			if (MSG.length !== 0) {
				//var Arra = [];
				this._Dialog = sap.ui.xmlfragment("com.app.portal.PORTAL.fragments.UploadMessanger", this);
				var array = [];
				for (var i = 0; i < MSG.length; i++) {
					var obj = {};
					if (MSG[i].StatusInd === "S") {
						obj.title = MSG[i].DocType + ": " + MSG[i].Remark;
						obj.description = "Created Successfully";
						//obj .counter = Scounter;
					} else {
						obj.title = MSG[i].DocType + ": " + MSG[i].Remark;
						obj.description = "Error";
						//obj.counter = Ecounter;
					}
					array.push(obj);
				}
				var oModel = new JSONModel(array);
				this._Dialog.setModel(oModel);
				this._Dialog.open();
				// localStorage.loader = "false";
			}
			oUploadCollection.setValue("");
			// oUploadCollection.setUploadEnabled(true);
			this.onrefresh();
		},
		onAfterRendering: function () {
			// var URL = "/sap/opu/odata/SAP/ZUPLOAD_FILE_NEW_SRV/";
			// var oData3 = new sap.ui.model.odata.ODataModel(URL, false);
			// var MSG;
			// var entity3 = "/Return_apSet";

			// oData3.read(entity3, null, null, false, function (Data2) {
			// 	MSG = Data2.results;
			// });
			// if (MSG.length !== 0 && localStorage.loader === "true") {
			// 	//var Arra = [];
			// 	this._Dialog = sap.ui.xmlfragment("com.app.portal.PORTAL.fragments.UploadMessanger", this);

			// 	var array = [];
			// 	for (var i = 0; i < MSG.length; i++) {
			// 		var obj = {};
			// 		if (MSG[i].StatusInd === "S") {
			// 			obj.title = MSG[i].DocType + ": " + MSG[i].Remark;
			// 			obj.description = "Created Successfully";
			// 			//obj.counter = Scounter;
			// 		} else {
			// 			obj.title = MSG[i].DocType + ": " + MSG[i].Remark;
			// 			obj.description = "Error";
			// 			//obj.counter = Ecounter;
			// 		}
			// 		array.push(obj);
			// 	}
			// 	var oModel = new JSONModel(array);
			// 	this._Dialog.setModel(oModel);
			// 	this._Dialog.open();
			// 	localStorage.loader = "false";
			// }
		},
		close: function () {
			var that = this;
			that._Dialog.close();
		},
		handleTypeMissmatch: function (oEvent) {
			var aFileTypes = oEvent.getSource().getFileType();
			jQuery.each(aFileTypes, function (key, value) {
				aFileTypes[key] = "." + value;
			});
			var sSupportedFileTypes = aFileTypes.join(", ");
			sap.m.MessageBox.alert("The file type ." + oEvent.getParameter("fileType") +
				" is not supported.Choose one of the following types: " +
				sSupportedFileTypes);
		},
		onPOSearch: function (oEvent) {
			var oView = this.getView();
			var oTable = oView.byId("Table1");
			var mparams = oEvent.getParameter("query");
			var oBinding = oTable.getBinding("rows");
			var oFilter = new sap.ui.model.Filter("Ebeln", sap.ui.model.FilterOperator.Contains, mparams);
			oBinding.filter([oFilter]);
		},
		onPOLiveSearch: function (oEvent) {
			var oView = this.getView();
			var oTable = oView.byId("Table1");
			var mparams = oEvent.getParameter("newValue");
			var oBinding = oTable.getBinding("rows");
			var oFilter = new sap.ui.model.Filter("Ebeln", sap.ui.model.FilterOperator.Contains, mparams);

			oBinding.filter([oFilter]);
		},

		onSearch: function (oEvent) {
			var oView = this.getView();
			var oTable = oView.byId("stocktable");
			var mparams = oEvent.getParameter("query");
			var oBinding = oTable.getBinding("rows");
			//var oFilter = new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.Contains, mparams);
			var oFilter = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.Contains, mparams),
					new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.Contains, mparams),
					new sap.ui.model.Filter("Lgort", sap.ui.model.FilterOperator.Contains, mparams)
				]
			});

			oBinding.filter([oFilter]);
		},
		
		//date
			handleChange: function (oEvent) {
			var oView = this.getView();
	var oTable = oView.byId("Table1");
	var sValue = oEvent.getParameter("value");
	var oBinding = oTable.getBinding("rows");
	var oFilter = new sap.ui.model.Filter({
											filters:[new sap.ui.model.Filter("Aedat", sap.ui.model.FilterOperator.Contains, sValue)]
				});
				
			oBinding.filter([oFilter]);
		},
		
		onSOSearch: function (oEvent) {
			var oView = this.getView();
			var oTable = oView.byId("salestable");
			var mparams = oEvent.getParameter("query");
			var oBinding = oTable.getBinding("items");
			//var oFilter = new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.Contains, mparams);
			var oFilter = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.Contains, mparams),
					new sap.ui.model.Filter("Vkorg", sap.ui.model.FilterOperator.Contains, mparams),
					new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.Contains, mparams)
				]
			});

			oBinding.filter([oFilter]);
		},

		PO: function (oEvent) {

			//var oModel = //sap.ui.getCore().getModel();
			var oExport = new Export({

				exportType: new ExportTypeCSV({
					fileExtension: "csv",
					separatorChar: ","
				}),

				models: new JSONModel(),

				rows: {
					path: "/"
				},
				columns: [{
					name: "PO ID",
					template: {
						content: ""
					}
				}, {
					name: "Purchase Order ",
					template: {
						content: ""
					}
				}, {
					name: "Purchasing organization ",
					template: {
						content: ""
					}
				}, {
					name: "Purchasing Group ",
					template: {
						content: ""
					}
				}, {
					name: "Company code",
					template: {
						content: ""
					}
				}, {
					name: "Material ",
					template: {
						content: ""
					}
				}, {
					name: "UOM",
					template: {
						content: ""
					}

				}, {
					name: "Quantity",
					template: {
						content: ""
					}

				}, {
					name: "Plant",
					template: {
						content: ""
					}
				}, {
					name: "Storage Location",
					template: {
						content: ""
					}
				}, {
					name: "Net price",
					template: {
						content: ""
					}
				}, {
					name: "Purchase Line Item ",
					template: {
						content: ""
					}
				}, {
					name: "Order Type",
					template: {
						content: ""
					}
				}, {
					name: "Vendors No",
					template: {
						content: ""
					}
				}, {
					name: "Delivery Date",
					template: {
						content: ""
					}
				}, {
					name: "Supplier to be Supplied",
					template: {
						content: ""
					}
				}, {
					name: "Item category",
					template: {
						content: ""
					}
				}, {
					name: "Reference",
					template: {
						content: ""
					}
				}, {
					name: "message",
					template: {
						content: ""
					}
				}]
			});
			//oExport.saveFile();
			oExport.saveFile("Purchase order").catch(function (oError) {

			}).then(function () {
				oExport.destroy();
			});
		},

		ASN: function (oEvent) {

			//var oModel = //sap.ui.getCore().getModel();
			var oExport = new Export({

				exportType: new ExportTypeCSV({
					fileExtension: "csv",
					separatorChar: ","
				}),

				models: new JSONModel(),

				rows: {
					path: "/"
				},
				columns: [{
					name: "po_number",
					template: {
						content: ""
					}
				}, {
					name: "po_item",
					template: {
						content: ""
					}
				}, {
					name: "Quantity",
					template: {
						content: ""
					}
				}, {
					name: "BILL_OF_LADING",
					template: {
						content: ""
					}
				}, {
					name: "UOM",
					template: {
						content: ""
					}

				}, {
					name: "Ship From",
					template: {
						content: ""
					}
				}, {
					name: "SUPP_VENDOR",
					template: {
						content: ""
					}
				}, {
					name: "Batch",
					template: {
						content: ""
					}
				}, {
					name: "Shipment Date",
					template: {
						content: ""
					}
				}, {
					name: "Material",
					template: {
						content: ""
					}
				}, {
					name: "Junk*",
					template: {
						content: ""
					}
				}]
			});
			//oExport.saveFile();
			oExport.saveFile("ASN").catch(function (oError) {

			}).then(function () {
				oExport.destroy();
			});
		},

		GVMT_GR: function (oEvent) {

			//var oModel = //sap.ui.getCore().getModel();
			var oExport = new Export({

				exportType: new ExportTypeCSV({
					fileExtension: "csv",
					separatorChar: ","
				}),

				models: new JSONModel(),

				rows: {
					path: "/"
				},
				columns: [{
					name: "po_number",
					template: {
						content: ""
					}
				}, {
					name: "Item Number",
					template: {
						content: ""
					}
				}, {
					name: "Quantity",
					template: {
						content: ""
					}
				}, {
					name: "plant",
					template: {
						content: ""
					}
				}, {
					name: "material",
					template: {
						content: ""
					}

				}, {
					name: "UOM",
					template: {
						content: ""
					}
				}, {
					name: "StockType",
					template: {
						content: ""
					}
				}, {
					name: "Junk",
					template: {
						content: ""
					}
				}]
			});
			//oExport.saveFile();
			oExport.saveFile("GVMT_GR").catch(function (oError) {

			}).then(function () {
				oExport.destroy();
			});
		},

		INVE: function (oEvent) {

			//var oModel = //sap.ui.getCore().getModel();
			var oExport = new Export({

				exportType: new ExportTypeCSV({
					fileExtension: "csv",
					separatorChar: ","
				}),

				models: new JSONModel(),

				rows: {
					path: "/"
				},
				columns: [{
					name: "po_number",
					template: {
						content: ""
					}
				}, {
					name: "tax_code",
					template: {
						content: ""
					}
				}, {
					name: "Vendor",
					template: {
						content: ""
					}
				}, {
					name: "PO_ITEM",
					template: {
						content: ""
					}
				}, {
					name: "Material",
					template: {
						content: ""
					}

				}, {
					name: "Batch",
					template: {
						content: ""
					}
				}, {
					name: "Qty",
					template: {
						content: ""
					}
				}, {
					name: "UOM",
					template: {
						content: ""
					}
				}, {
					name: "NET_PR",
					template: {
						content: ""
					}
				}, {
					name: "junk",
					template: {
						content: ""
					}
				}]
			});
			//oExport.saveFile();
			oExport.saveFile("Invoice").catch(function (oError) {

			}).then(function () {
				oExport.destroy();
			});
		},

		// 	UD:  function (oEvent) {

		// 	//var oModel = //sap.ui.getCore().getModel();
		// 	var oExport = new Export({

		// 		exportType: new ExportTypeCSV({
		// 			fileExtension: "csv",
		// 			separatorChar: ","
		// 		}),

		// 		models: new JSONModel(),

		// 		rows: {
		// 			 path: "/"
		// 		},
		// 		columns: [{
		// 			name: "Purchasing organisation",
		// 			template: {
		// 				content: ""
		// 			}
		// 		}, {
		// 			name: "Purchasing group",
		// 			template: {
		// 				content: ""
		// 			}
		// 		}, {
		// 			name: "Company code",
		// 			template: {
		// 				content: ""
		// 			}
		// 		}, {
		// 			name: "Material number",
		// 			template: {
		// 				content: ""
		// 			}
		// 		}, {
		// 			name: "Purchase order quantity",
		// 			template: {
		// 				content: ""
		// 			}

		// 		}, {
		// 			name: "Plant",
		// 			template: {
		// 				content: ""
		// 			}
		// 		}, {
		// 			name: "Storage Location",
		// 			template: {
		// 				content: ""
		// 			}
		// 		}, {
		// 			name: "Net price",
		// 			template: {
		// 				content: ""
		// 			}
		// 		}, {
		// 			name: "Item number",
		// 			template: {
		// 				content: ""
		// 			}
		// 		}, {
		// 			name: "Purchasing Document Type",
		// 			template: {
		// 				content: ""
		// 			}
		// 		}, {
		// 			name: "Vendors acc number",
		// 			template: {
		// 				content: ""
		// 			}
		// 		}]
		// 	});
		// 	//oExport.saveFile();
		// 	oExport.saveFile("UD_CSV").catch(function (oError) {

		// 	}).then(function () {
		// 		oExport.destroy();
		// 	});
		// },
		TR: function (oEvent) {

			//var oModel = //sap.ui.getCore().getModel();
			var oExport = new Export({

				exportType: new ExportTypeCSV({
					fileExtension: "csv",
					separatorChar: ","
				}),

				models: new JSONModel(),

				rows: {
					path: "/"
				},
				columns: [{
					name: "Purchasing organisation",
					template: {
						content: ""
					}
				}, {
					name: "Purchasing group",
					template: {
						content: ""
					}
				}, {
					name: "Company code",
					template: {
						content: ""
					}
				}, {
					name: "Material number",
					template: {
						content: ""
					}
				}, {
					name: "Purchase order quantity",
					template: {
						content: ""
					}

				}, {
					name: "Plant",
					template: {
						content: ""
					}
				}, {
					name: "Storage Location",
					template: {
						content: ""
					}
				}, {
					name: "Net price",
					template: {
						content: ""
					}
				}, {
					name: "Item number",
					template: {
						content: ""
					}
				}, {
					name: "Purchasing Document Type",
					template: {
						content: ""
					}
				}, {
					name: "Vendors acc number",
					template: {
						content: ""
					}
				}]
			});
			//oExport.saveFile();
			oExport.saveFile("TR_CSV").catch(function (oError) {

			}).then(function () {
				oExport.destroy();
			});
		},

		openfragment: function () {
			this._Dialog = sap.ui.xmlfragment("com.app.portal.PORTAL.fragments.portal",
				this);
			this._Dialog.open();
		},
		closeDialog: function () {
			this._Dialog.close();
			this._Dialog.destroy();
		}

	});

});

// 		onInit: function () {
// 			var URL = "/sap/opu/odata/SAP/ZUPLOAD_FILE_NEW_SRV/";
// 			var oData = new sap.ui.model.odata.ODataModel(URL, false);
// 			var errorlogs = [];
// 			var oDataModel = new sap.ui.model.json.JSONModel();
// 			var entity = "/ERROR_RECORDSSet";
// 			var array = [];
// 			var object = {};
// 			var objec1t = {};
// 			oData.read(entity, null, null, false,
// 				function (Data) {
// 					errorlogs = Data;
// 					for (var i = 0; i < errorlogs.results.length; i++) {
// 						object = errorlogs.results[i].Zdate;
// 						objec1t = errorlogs.results[i];
// 						var day = object.slice(8, 10);
// 						var mm = object.slice(5, 7);
// 						var year = object.slice(0, 4);

// 						var dt = mm + "." + day + "." + year;

// 						objec1t.Zdate = dt;
// 						array.push(objec1t);
// 						objec1t = {};
// 					}
// 				});
// 			errorlogs.results = array;
// 			oDataModel.setData(errorlogs);
// 			this.getView().byId("Errorlog").setModel(oDataModel);
// 			// //	 oData.refresh(true);

// 			//---------po table--------------

// 			var oData1 = new sap.ui.model.odata.ODataModel(URL, false);
// 			var po = [];
// 			var oDataModel1 = new sap.ui.model.json.JSONModel();
// 			var entity1 = "/PO_Display1Set";
// 			var array1 = [];
// 			var obj = {};
// 			var object2 = {};
// 			oData1.read(entity1, null, null, false,
// 				function (Data1) {
// 					po = Data1;
// 					for (var j = 0; j < po.results.length; j++) {
// 						obj = po.results[j].Aedat;
// 						object2 = po.results[j];
// 						var day = obj.slice(8, 10);
// 						var mm = obj.slice(5, 7);
// 						var year = obj.slice(0, 4);

// 						var dt = mm + "." + day + "." + year;

// 						object2.Aedat = dt;
// 						array1.push(object2);
// 						object2 = {};
// 					}

// 				});
// 			po.results = array1;
// 			oDataModel1.setData(po);
// 			this.getView().byId("Table1").setModel(oDataModel1);
// 			// oData1.refresh(true);
// 			//---------stock table-----------

// 			var oData2 = new sap.ui.model.odata.ODataModel(URL, false);
// 			var stock = [];
// 			var oDataModel2 = new sap.ui.model.json.JSONModel();
// 			var entity2 = "/zinventorySet";

// 			oData2.read(entity2, null, null, false,
// 				function (Data2) {
// 					stock = Data2;

// 				});

// 			oDataModel2.setData(stock);
// 			this.getView().byId("stocktable").setModel(oDataModel2);

// 		},
// 		//Date From and To Filter *Start*
// 		handleChange: function (oEvent) {
// 			debugger;
// 			//var selected = oEvent;
// 			var aFilters = [];
// 			var outerFilters = [];
// 			var dDateStart = new Date(oEvent.getParameter("value"));
// 			var oTable = this.byId("Table1");
// 			var HdateFormat = sap.ui.core.format.DateFormat.getDateInstance({
// 				pattern: "MM.dd.YYYY"
// 			});
// 			dDateStart = HdateFormat.format(dDateStart);
// 			var id = oEvent.getSource().getId();
// 			var count = id.search("from");
// 			id = id.slice(count, id.length);
// 			if (id !== "from") {
// 				dDateStart = this._DateStart;
// 				var dDateEnd = new Date(oEvent.getParameter("value"));
// 				dDateEnd = HdateFormat.format(dDateEnd);
// 				aFilters.push(new Filter("Aedat", sap.ui.model.FilterOperator.Contains, dDateEnd));

// 			} else {
// 				this._DateStart = dDateStart;
// 			}
// 			//var isValidDate = oEvent.getParameter("valid");

// 			if (dDateStart === "") {
// 				//When clear was pressed on search field
// 				oTable.getBinding("rows").filter(null);
// 			} else {
// 				aFilters.push(new Filter("Aedat", sap.ui.model.FilterOperator.Contains, dDateStart));

// 				outerFilters.push(new Filter(aFilters));
// 				//aFilters = [];
// 				/*aFilters.push(new Filter({
// 					path: "Aedat",
// 					operator: FilterOperator.Contains,
// 					value1: dDateStart,
// 					value2: dDateEnd
// 				}));*/
// 			}

// 			oTable.getBinding("rows").filter(new Filter({
// 				filters: outerFilters,
// 				and: true //Default is OR between filters
// 			}));
// 		},
// 		// handleDRSChange: function(oEvents){
// 		// 	var sEvent =oEvents;
// 		// },
// 		//Date From and To Filter *End*
// 		onBackPress1: function (oEvent) {
// 			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
// 			//	var oModel = sap.ui.getCore().getModel("Globalmodel");
// 			oRouter.navTo("TargetView1");
// 		},
// 		onUpload: function () {

// 			var oFileUploader = this.getView().byId("fileUploader");
// 			if (!oFileUploader.getValue()) {
// 				sap.m.MessageBox.alert("Choose a file first");
// 				return;
// 			}
// 			var oFileName = oFileUploader.getFocusDomRef();

// 			var file = oFileName.files[0];
// 			var csrfToken = "";
// 			var aData = jQuery.ajax({
// 				url: "/sap/opu/odata/SAP/ZUPLOAD_FILE_NEW_SRV",
// 				headers: {
// 					"X-CSRF-Token": "Fetch",
// 					"X-Requested-With": "XMLHttpRequest",
// 					"DataServiceVersion": "2.0"
// 				},
// 				type: "GET",
// 				contentType: "application/json",
// 				//	contentType: "application/atom+xml",
// 				dataType: "json",
// 				success: function (data, textStatus, jqXHR) {
// 					csrfToken = jqXHR.getResponseHeader("x-csrf-token");
// 					oFileUploader.setSendXHR(true);
// 					sap.m.MessageBox.success("File Uploaded");
// 					localStorage.loader = "true";
// 					document.location.reload(true);
// 					// oFileName.refresh(true);

// 					oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
// 						name: "X-CSRF-Token",
// 						value: csrfToken
// 					}));
// 					var FName = oFileUploader.getValue(); //newly added code
// 					oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
// 						name: "slug",
// 						//     value : file
// 						value: FName // value changed
// 					}));
// 					oFileUploader.setUploadUrl("/sap/opu/odata/SAP/ZUPLOAD_FILE_NEW_SRV/FILESet");
// 					oFileUploader.upload();

// 				},

// 				error: function (XMLHttpRequest, textStatus, errorThrown) {
// 					//  sucess: function (XMLHttpRequest, textStatus) {
// 					sap.m.MessageBox.error("file Upload unsuccessful" + errorThrown);
// 				}

// 			});

// 		},
// 		onAfterRendering: function () {
// 			var URL = "/sap/opu/odata/SAP/ZUPLOAD_FILE_NEW_SRV/";
// 			var oData3 = new sap.ui.model.odata.ODataModel(URL, false);
// 			var MSG;
// 			var entity3 = "/Return_apSet";

// 			oData3.read(entity3, null, null, false, function (Data2) {
// 				MSG = Data2.results;
// 			});
// 			if (MSG.length !== 0 && localStorage.loader === "true") {
// 				//var Arra = [];
// 				this._Dialog = sap.ui.xmlfragment("com.app.portal.PORTAL.fragments.UploadMessanger", this);
// 				/*var Scounter = 0;
// 				var Ecounter = 0;
// 				for (var i = 0; i < MSG.length; i++) {
// 					var obj = {};
// 					if (MSG[i].Status === "S") {
// 						Scounter = Scounter + 1;
// 					} else {
// 						Ecounter = Ecounter + 1;
// 					}
// 				}
// 				var trst = "true";
// 				*/
// 				var array = [];
// 				for (var i = 0; i < MSG.length; i++) {
// 					var obj = {};
// 					if (MSG[i].StatusInd === "S") {
// 						obj.title = MSG[i].DocType + ": " + MSG[i].Remark;
// 						obj.description = "Created Successfully";
// 						//obj.counter = Scounter;
// 					} else {
// 						obj.title = MSG[i].DocType + ": " + MSG[i].Remark;
// 						obj.description = "Error";
// 						//obj.counter = Ecounter;
// 					}
// 					array.push(obj);
// 				}
// 				var oModel = new JSONModel(array);
// 				this._Dialog.setModel(oModel);
// 				this._Dialog.open();
// 				localStorage.loader = "false";
// 			}
// 		},
// 		close: function () {
// 			this._Dialog.close();
// 		},
// 		handleTypeMissmatch: function (oEvent) {
// 			var aFileTypes = oEvent.getSource().getFileType();
// 			jQuery.each(aFileTypes, function (key, value) {
// 				aFileTypes[key] = "." + value;
// 			});
// 			var sSupportedFileTypes = aFileTypes.join(", ");
// 			sap.m.MessageBox.alert("The file type ." + oEvent.getParameter("fileType") +
// 				" is not supported.Choose one of the following types: " +
// 				sSupportedFileTypes);
// 		},
// 		onPOSearch: function (oEvent) {
// 			var oView = this.getView();
// 			var oTable = oView.byId("Table1");
// 			var mparams = oEvent.getParameter("query");
// 			var oBinding = oTable.getBinding("rows");
// 			var oFilter = new sap.ui.model.Filter("Ebeln", sap.ui.model.FilterOperator.Contains, mparams);
// 			oBinding.filter([oFilter]);
// 		},
// 		onPOLiveSearch: function (oEvent) {
// 			var oView = this.getView();
// 			var oTable = oView.byId("Table1");
// 			var mparams = oEvent.getParameter("newValue");
// 			var oBinding = oTable.getBinding("rows");
// 			var oFilter = new sap.ui.model.Filter("Ebeln", sap.ui.model.FilterOperator.Contains, mparams);

// 			oBinding.filter([oFilter]);
// 		},

// 		onSearch: function (oEvent) {
// 			var oView = this.getView();
// 			var oTable = oView.byId("stocktable");
// 			var mparams = oEvent.getParameter("query");
// 			var oBinding = oTable.getBinding("rows");
// 			//var oFilter = new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.Contains, mparams);
// 			var oFilter = new sap.ui.model.Filter({
// 				filters: [new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.Contains, mparams),
// 					new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.Contains, mparams),
// 					new sap.ui.model.Filter("Lgort", sap.ui.model.FilterOperator.Contains, mparams)
// 				]
// 			});

// 			oBinding.filter([oFilter]);
// 		},
// 		// onCostSearch : function(oEvent){
// 		// 	var oView = this.getView();
// 		// 	var oTable1 = oView.byId("Costtable");
// 		// 	var mparams1 = oEvent.getParameter("query");
// 		// 	var oBinding1 = oTable1.getBinding("rows");
// 		// 	//var oFilter = new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.Contains, mparams);
// 		// 		var oFilter = new sap.ui.model.Filter({
// 		// 									filters:[new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.Contains, mparams1),
// 		// 											 new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.Contains, mparams1)
// 		// 											 //new sap.ui.model.Filter("Lgort", sap.ui.model.FilterOperator.Contains, mparams)
// 		// 									        ]
// 		// 		});

// 		// 	oBinding1.filter([oFilter]);

// 		// },
// 		onSOSearch: function (oEvent) {
// 			var oView = this.getView();
// 			var oTable = oView.byId("salestable");
// 			var mparams = oEvent.getParameter("query");
// 			var oBinding = oTable.getBinding("items");
// 			//var oFilter = new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.Contains, mparams);
// 			var oFilter = new sap.ui.model.Filter({
// 				filters: [new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.Contains, mparams),
// 					new sap.ui.model.Filter("Vkorg", sap.ui.model.FilterOperator.Contains, mparams),
// 					new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.Contains, mparams)
// 				]
// 			});

// 			oBinding.filter([oFilter]);
// 		},

// 		PO: function (oEvent) {

// 			//var oModel = //sap.ui.getCore().getModel();
// 			var oExport = new Export({

// 				exportType: new ExportTypeCSV({
// 					fileExtension: "csv",
// 					separatorChar: ","
// 				}),

// 				models: new JSONModel(),

// 				rows: {
// 					path: "/"
// 				},
// 				columns: [{
// 					name: "PO ID",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Purchase Order ",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Purchasing organization ",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Purchasing Group ",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Company code",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Material ",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "UOM",
// 					template: {
// 						content: ""
// 					}

// 				}, {
// 					name: "Quantity",
// 					template: {
// 						content: ""
// 					}

// 				}, {
// 					name: "Plant",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Storage Location",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Net price",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Purchase Line Item ",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Order Type",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Vendors No",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Delivery Date",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Supplier to be Supplied",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Item category",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "message",
// 					template: {
// 						content: ""
// 					}
// 				}]
// 			});
// 			//oExport.saveFile();
// 			oExport.saveFile("Purchase order").catch(function (oError) {

// 			}).then(function () {
// 				oExport.destroy();
// 			});
// 		},

// 		ASN: function (oEvent) {

// 			//var oModel = //sap.ui.getCore().getModel();
// 			var oExport = new Export({

// 				exportType: new ExportTypeCSV({
// 					fileExtension: "csv",
// 					separatorChar: ","
// 				}),

// 				models: new JSONModel(),

// 				rows: {
// 					path: "/"
// 				},
// 				columns: [{
// 					name: "po_number",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "po_item",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "deliv_qty",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "BILL_OF_LADING",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Quantity",
// 					template: {
// 						content: ""
// 					}

// 				}, {
// 					name: "Vendor",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "SUPP_VENDOR",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Batch",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Junk*",
// 					template: {
// 						content: ""
// 					}
// 				}]
// 			});
// 			//oExport.saveFile();
// 			oExport.saveFile("ASN").catch(function (oError) {

// 			}).then(function () {
// 				oExport.destroy();
// 			});
// 		},

// 		GVMT_GR: function (oEvent) {

// 			//var oModel = //sap.ui.getCore().getModel();
// 			var oExport = new Export({

// 				exportType: new ExportTypeCSV({
// 					fileExtension: "csv",
// 					separatorChar: ","
// 				}),

// 				models: new JSONModel(),

// 				rows: {
// 					path: "/"
// 				},
// 				columns: [{
// 					name: "po_number",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "po_item",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "entry_qnt",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "plant",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "material",
// 					template: {
// 						content: ""
// 					}

// 				}, {
// 					name: "UOM",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "StockType",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Junk",
// 					template: {
// 						content: ""
// 					}
// 				}]
// 			});
// 			//oExport.saveFile();
// 			oExport.saveFile("GVMT_GR").catch(function (oError) {

// 			}).then(function () {
// 				oExport.destroy();
// 			});
// 		},

// 		INVE: function (oEvent) {

// 			//var oModel = //sap.ui.getCore().getModel();
// 			var oExport = new Export({

// 				exportType: new ExportTypeCSV({
// 					fileExtension: "csv",
// 					separatorChar: ","
// 				}),

// 				models: new JSONModel(),

// 				rows: {
// 					path: "/"
// 				},
// 				columns: [{
// 					name: "po_number",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "tax_code",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Purchase Order Line",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Batch Number",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Material",
// 					template: {
// 						content: ""
// 					}

// 				}, {
// 					name: "UOM",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Vendor",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Quantity",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Amount",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "junk",
// 					template: {
// 						content: ""
// 					}
// 				}]
// 			});
// 			//oExport.saveFile();
// 			oExport.saveFile("Invoice").catch(function (oError) {

// 			}).then(function () {
// 				oExport.destroy();
// 			});
// 		},

// 		// 	UD:  function (oEvent) {

// 		// 	//var oModel = //sap.ui.getCore().getModel();
// 		// 	var oExport = new Export({

// 		// 		exportType: new ExportTypeCSV({
// 		// 			fileExtension: "csv",
// 		// 			separatorChar: ","
// 		// 		}),

// 		// 		models: new JSONModel(),

// 		// 		rows: {
// 		// 			 path: "/"
// 		// 		},
// 		// 		columns: [{
// 		// 			name: "Purchasing organisation",
// 		// 			template: {
// 		// 				content: ""
// 		// 			}
// 		// 		}, {
// 		// 			name: "Purchasing group",
// 		// 			template: {
// 		// 				content: ""
// 		// 			}
// 		// 		}, {
// 		// 			name: "Company code",
// 		// 			template: {
// 		// 				content: ""
// 		// 			}
// 		// 		}, {
// 		// 			name: "Material number",
// 		// 			template: {
// 		// 				content: ""
// 		// 			}
// 		// 		}, {
// 		// 			name: "Purchase order quantity",
// 		// 			template: {
// 		// 				content: ""
// 		// 			}

// 		// 		}, {
// 		// 			name: "Plant",
// 		// 			template: {
// 		// 				content: ""
// 		// 			}
// 		// 		}, {
// 		// 			name: "Storage Location",
// 		// 			template: {
// 		// 				content: ""
// 		// 			}
// 		// 		}, {
// 		// 			name: "Net price",
// 		// 			template: {
// 		// 				content: ""
// 		// 			}
// 		// 		}, {
// 		// 			name: "Item number",
// 		// 			template: {
// 		// 				content: ""
// 		// 			}
// 		// 		}, {
// 		// 			name: "Purchasing Document Type",
// 		// 			template: {
// 		// 				content: ""
// 		// 			}
// 		// 		}, {
// 		// 			name: "Vendors acc number",
// 		// 			template: {
// 		// 				content: ""
// 		// 			}
// 		// 		}]
// 		// 	});
// 		// 	//oExport.saveFile();
// 		// 	oExport.saveFile("UD_CSV").catch(function (oError) {

// 		// 	}).then(function () {
// 		// 		oExport.destroy();
// 		// 	});
// 		// },
// 		TR: function (oEvent) {

// 			//var oModel = //sap.ui.getCore().getModel();
// 			var oExport = new Export({

// 				exportType: new ExportTypeCSV({
// 					fileExtension: "csv",
// 					separatorChar: ","
// 				}),

// 				models: new JSONModel(),

// 				rows: {
// 					path: "/"
// 				},
// 				columns: [{
// 					name: "Purchasing organisation",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Purchasing group",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Company code",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Material number",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Purchase order quantity",
// 					template: {
// 						content: ""
// 					}

// 				}, {
// 					name: "Plant",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Storage Location",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Net price",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Item number",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Purchasing Document Type",
// 					template: {
// 						content: ""
// 					}
// 				}, {
// 					name: "Vendors acc number",
// 					template: {
// 						content: ""
// 					}
// 				}]
// 			});
// 			//oExport.saveFile();
// 			oExport.saveFile("TR_CSV").catch(function (oError) {

// 			}).then(function () {
// 				oExport.destroy();
// 			});
// 		},

// 		//////////////// search for Material Plant Storage Loc   ///////////////
// 		openfragment: function () {
// 			this._Dialog = sap.ui.xmlfragment("com.app.portal.PORTAL.fragments.portal",
// 				this);
// 			this._Dialog.open();
// 		},
// 		closeDialog: function () {
// 				this._Dialog.close();
// 			}
// 			//////////////// search for Material Plant Storage Loc   ///////////////

// 	});

// });