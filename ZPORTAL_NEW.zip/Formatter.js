sap.ui.define(function () {
	"use strict";

	var Formatter = {
	Dateformatter : function(val) {
			if(val){
			var date = new Date(val);
			var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern : "dd.MM.yyyy"
			});
			val = oDateFormat.format(date);
			
		}else{
			val = "";
			}
			return val;
	},
		getPOTableCount: function (oEvent) {
			var cont;
			new sap.ui.model.odata.ODataModel('/sap/opu/odata/SAP/ZUPLOAD_FILE_NEW_SRV/', false).read('/PO_Display1Set', null, null,
				false,
				function (responses) {
					cont = responses.results.length;
				});
			return cont;
		},
		getStockTableCount: function (oEvent) {
			var cont;
			new sap.ui.model.odata.ODataModel('/sap/opu/odata/SAP/ZUPLOAD_FILE_NEW_SRV/', false).read('/zinventorySet', null, null,
				false,
				function (responses) {
					cont = responses.results.length;
				});
			return cont;
		},
		availableState: function (ValueState) {
		//	var sStateValueToLower = sStateValue.Status();

			switch (ValueState) {
				case "New PO":
					return 8;
				case "Old PO":
					return 3;
				case "Goods Reciept Completed":
					return 6;
				case "outbound Delivery Created":
					return 4;
				case "GI Completed & ASN Created":
					return 1;
				case "Invoice Reciept Completed":
					return 1;
				case "ASN Created":
					return 7;
					default:
					return 9;
				
				
			}
			
			 
		}
	};

	return Formatter;

}, /* bExport= */ true);
