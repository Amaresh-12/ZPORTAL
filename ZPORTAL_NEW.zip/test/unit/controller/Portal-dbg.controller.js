/*global QUnit*/

sap.ui.define([
	"com/app/portal/PORTAL/controller/Portal.controller"
], function (Controller) {
	"use strict";

	QUnit.module("Portal Controller");

	QUnit.test("I should test the Portal controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});