sap.ui.define([
	"com/app/portal/PORTAL/test/unit/controller/Portal.controller"
], function () {
	"use strict";
});